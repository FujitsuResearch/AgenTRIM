"""AGENTRIM integration for AgentDojo."""
