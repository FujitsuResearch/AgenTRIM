"""AGENTRIM tool extractor."""
